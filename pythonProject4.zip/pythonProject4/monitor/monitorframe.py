from PyQt5 import QtCore
from PyQt5.Qt import Qt
from PyQt5.QtGui import QImage, QPixmap
from PyQt5.QtWidgets import QDialog
from monitor.mfui import Ui_Dialog
from ai.person import person_detect
from ai.personshibie import person_attr
import cv2
import numpy as np


class MonitorDialog(QDialog):
    def __init__(self):
        super().__init__()
        self.ui = Ui_Dialog()
        self.ui.setupUi(self)
        ##self.th1 = Video('data/peope.jpg')
        self.image_path = 'data/peope.jpg'
        # 绑定信号与槽函数

        ##self.th1.send.connect(self.showimg)

        num = person_detect(cv2.imread(self.image_path))
        # print(num)
        self.load_and_show_image(num)

        img = person_attr(cv2.imread(self.image_path))
        # cv2.imshow('q',img)
        # cv2.waitKey(0)
        # cv2.destroyAllWindows()
        #
        # imgae = QImage(img.data, self.ui.video1.width, self.ui.video1.height, 3*self.ui.video1.width, QImage.Format_RGB888).rgbSwapped()

        img = np.ascontiguousarray(img)

        # 计算步长
        stride = img.shape[1] * 3  # 宽度乘以每个像素的字节数（RGB）

        # 创建QImage对象
        # 注意：这里假设img是BGR格式的，并且我们需要将其转换为RGB并显示
        imgae = QImage(img.data, img.shape[1], img.shape[0], stride, QImage.Format_RGB888).rgbSwapped()
        self.ui.video1.setPixmap(QPixmap.fromImage(imgae))
        ##self.th1.start()
        '''def showimg(self, h, w, c, b, th_id, image):
        imgae = QImage(b, w, h, w * c, QImage.Format_BGR888)
        pix = QPixmap.fromImage(imgae)
        if th_id == 1:
            # 自动缩放
            width = self.ui.video1.width()
            height = self.ui.video1.height()
            scale_pix = pix.scaled(width, height, Qt.KeepAspectRatio)
            self.ui.video1.setPixmap(scale_pix)
            # str(num) 类型转换
            self.ui.personnum.setText(str(num))'''
    def load_and_show_image(self, num):
        pixmap1 = QPixmap(self.image_path)
        self.ui.video1.setPixmap(pixmap1.scaled(self.ui.video1.size(),Qt.KeepAspectRatio))
        self.ui.personnum.setText(str(num))
        ##self.ui.video1.setPixmap(img)


