import requests
import base64
import cv2 as cv


# opencv 图片
def person_detect(img):
    request_url = "https://aip.baidubce.com/rest/2.0/image-classify/v1/body_num"
    _, encoded_image = cv.imencode('.jpg', img)
    base64_image = base64.b64encode(encoded_image)
    params = {"image":base64_image}
    access_token = '24.1c4e5b20f453e31c8fb7401fc4114305.2592000.1722761266.282335-90548897'
    request_url = request_url + "?access_token=" + access_token
    headers = {'content-type': 'application/x-www-form-urlencoded'}
    response = requests.post(request_url, data=params, headers=headers)
    num = 0
    if response:
        data = response.json()
        #print(data)
        num = data['person_num']
        #print(num)
    return num
    # # 等待按键，然后关闭窗口
    # cv.waitKey(0)
    # cv.destroyAllWindows()
